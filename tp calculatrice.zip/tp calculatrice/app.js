//variables globales
//elements memoire et ecran
const memoireElt = document.querySelector("memoire");
const ecranElt = document.querySelector(".ecran");

//stockage de la valeur de l'ecran precedent
var precedent = 0;

//stockage de l'affichage
var affichage = "";

//stockage de l'operation
var operation = null;

// initialisation de la mémoire
var memoire;

window.onload = () => {
	//on écoute les clics sur les touches
var touches = document.querySelectorAll("button");

for(var touche of touches){
	touche.addEventListener("click", gererTouches);
}
}

//cette fonction réagit aux cliques sur les touches
function gererTouches(){
	var touche = this.innerText;

	//verifions si c'est un chiffre ou un point
	if (parseFloat(touche) >= 0 || touche === ".") {

		//on met á jour la valeur d'affichage et on affiche sur l'ecran
		affichage = (affichage === "")? touche.toString() : affichage + touche.toString();
		ecranElt.innerText = affichage;
	} else{
		switch(touche){

			// touche pour effacer
			case "C" :
			   precedent = 0;
			   affichage = "";
			   operation = null;
			   ecranElt.innerText = 0;
			   break;
			// calcules
			case "+":
			case "-":
			case "*":
			case "/":

			      //on calcule la valeur résultat de l'étape précedente
			      precedent = (precedent === 0)? parseFloat(affichage) : calculer(precedent,parseFloat(affichage),operation);
			      // on met á jour l'ecran
			      ecranElt.innerText = precedent;
			      //on stocke l'operation
			      operation = touche;
			      // on réinitialise la variable d'affichage
			      affichage = "";
			    break;
			case "=" : 
			       //on calcule la valeur résultat de l'étape précedente
			      precedent = (precedent === 0)? parseFloat(affichage) : calculer(precedent,parseFloat(affichage),operation);
			      // on met á jour l'ecran
			      ecranElt.innerText = precedent;
			     
			      // on stocke le resultat dans la variable d'affichage
			      affichage = precedent;
			      // on reinitialise precedent
			      precedent = 0;
			      break;



		}
	}
}


/**
 * effectue les calculs
 * @param {number} nb1
 * @param {number} nb2
 * @param {string} operation
 * @returns number
 */

function calculer(nb1, nb2, operation){
   nb1 = parseFloat(nb1);
   nb2 = parseFloat(nb2);

      if (operation === "+") return nb1 + nb2;
      if (operation === "-") return nb1 -nb2;
      if (operation === "*") return nb1 * nb2;
      if (operation === "/") return nb1 / nb2;





}
